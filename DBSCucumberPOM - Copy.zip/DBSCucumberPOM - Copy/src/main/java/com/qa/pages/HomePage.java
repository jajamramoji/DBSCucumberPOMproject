package com.qa.pages;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.TestBase;

public class HomePage extends TestBase
{
	static Logger log= Logger.getLogger(HomePage.class.getName());
	//Page Factory
	@FindBy(xpath = "//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']") 
	WebElement source;
	@FindBy(xpath = "//input[@id='ctl00_mainContent_ddl_destinationStation1_CTXT']") 
	WebElement destination;
	@FindBy(xpath = "//div[@class='ui-datepicker-title']") 
	WebElement Month;
	@FindBy(xpath = "//span[@class='ui-icon ui-icon-circle-triangle-e']")
	WebElement nextMonth;
	@FindBy(xpath = "//a[@class='ui-state-default']")
	WebElement Day;
	
	@FindBy(xpath = "//input[@id='ctl00_mainContent_btn_FindFlights']") 
	WebElement Search;
	
	//Initializing the Page Objects:
	public HomePage(){
		PageFactory.initElements(driver, this);
		
	}
	
	public void source_Destination_Selection() throws InterruptedException{
		
		source.sendKeys("Hyderabad (HYD)");
		Thread.sleep(4000);
		destination.clear();
		destination.sendKeys("BLR");
		Thread.sleep(4000);
		
		//datePicker.
		
		//return new bookSpicejet();
		
	}
	
	public void dateSelection() throws InterruptedException
	{
		String month1="September 2020";
		
		while(!Month.getText().contains(month1)) {
			
			//System.out.println("hello");
			nextMonth.click();
			
		}
		
		
		 
	List<WebElement> day = driver.findElements(By.xpath("//a[@class='ui-state-default']"));
			
	for(int i=0; i<day.size(); i++) {
		
		
		if(day.get(i).getText().contains("5")) {
			log.info(day.get(i).getText());
			
			
			day.get(i).click();
			
			Thread.sleep(3000);
			
			
			break;
		}
		
		
	}
	
	 
	}
	public void searchButton(){
		Search.click();
		log.info(driver.getCurrentUrl());
		log.info(driver.getTitle());
	}

}
