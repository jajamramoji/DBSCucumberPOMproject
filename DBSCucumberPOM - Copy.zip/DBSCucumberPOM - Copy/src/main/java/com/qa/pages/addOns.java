package com.qa.pages;

import java.util.logging.Logger;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.util.TestBase;

public class addOns extends TestBase
{
	static Logger log= Logger.getLogger(addOns.class.getName());
	@FindBy(xpath = "//span[contains(text(),'Pay Now')]") 
	WebElement payButton;

	//Initializing the Page Objects:
	public addOns(){
		PageFactory.initElements(driver, this);
	}
	
	public void addonPay() throws InterruptedException{
		payButton.click();
		log.info("user click on pay button");
		log.info(driver.getCurrentUrl());
		Thread.sleep(3000);
	}
}
